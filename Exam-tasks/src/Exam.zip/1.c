#include <stdio.h>
#include <stdlib.h>

int main() {
    printf("\"I'm Groot\" (c) Groot");
    return 0;
}


// вывести на экран я есть грут

// подобное задание с виндовсом
// вывод c:window/...